/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment;

/**
 *
 * @author user
 */
/*import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class MapVisualization extends JFrame {
    private Graph graph;
    private Map<String, Point> locationPoints;
    
    public MapVisualization(Graph graph) {
        this.graph = graph;
        this.locationPoints = new HashMap<>();
        
        setTitle("Penang Location Map");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initializeLocationPoints();
        
        JPanel mapPanel = new MapPanel();
        add(mapPanel);
        
        setVisible(true);
    }
    
    private void initializeLocationPoints() {
        // Manually position the locations for visualization
        locationPoints.put("TanjungTokong", new Point(450, 50));
        locationPoints.put("TanjungBungah", new Point(750, 100));
        locationPoints.put("Gurney", new Point(450, 150));
        locationPoints.put("Komtar", new Point(450, 250));
        locationPoints.put("Jetty", new Point(150, 250));
        locationPoints.put("BatuFerringhi", new Point(1050, 150));
        locationPoints.put("Butterworth", new Point(150, 150));
        locationPoints.put("AyerItam", new Point(750, 250));
        locationPoints.put("PenangHill", new Point(1050, 250));
        locationPoints.put("BalikPulau", new Point(750, 350));
        locationPoints.put("USM", new Point(450, 350));
        locationPoints.put("Queensbay", new Point(450, 450));
        locationPoints.put("Airport", new Point(450, 550));
    }
    
    class MapPanel extends JPanel {
        private static final int NODE_RADIUS = 20;
        private static final int ARROW_SIZE = 8;
        
        public MapPanel() {
            setBackground(Color.WHITE);
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Draw connections
            g2d.setColor(Color.LIGHT_GRAY);
            BasicStroke stroke = new BasicStroke(2f);
            g2d.setStroke(stroke);
            
            // Use adjacency list to draw edges
            Map<String, List<Edge>> adjList = graph.getAdjList();
            for (String node : adjList.keySet()) {
                Point p1 = locationPoints.get(node);
                if (p1 == null) continue;
                
                for (Edge edge : adjList.get(node)) {
                    Point p2 = locationPoints.get(edge.destination);
                    if (p2 != null) {
                        // Draw the line
                        g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
                        
                        // Draw arrow head to indicate direction
                        drawArrow(g2d, p1.x, p1.y, p2.x, p2.y);
                        
                        // Draw distance and time
                        int midX = (p1.x + p2.x) / 2 + 5;
                        int midY = (p1.y + p2.y) / 2 - 5;
                        g2d.setColor(Color.BLUE);
                        g2d.drawString(edge.time + "min, " + edge.distance + "km", midX, midY);
                        g2d.setColor(Color.LIGHT_GRAY);
                    }
                }
            }
            
            // Draw nodes
            for (Map.Entry<String, Point> entry : locationPoints.entrySet()) {
                Point p = entry.getValue();
                String node = entry.getKey();
                
                // Draw circle
                g2d.setColor(Color.BLACK);
                g2d.fillOval(p.x - NODE_RADIUS, p.y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);
                
                // Draw border
                g2d.setColor(Color.BLACK);
                g2d.drawOval(p.x - NODE_RADIUS, p.y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);
                
                // Draw label
                FontMetrics metrics = g2d.getFontMetrics();
                int labelWidth = metrics.stringWidth(node);
                g2d.setColor(Color.BLACK);
                g2d.drawString(node, p.x - labelWidth/2, p.y - NODE_RADIUS - 5);
            }
        }
        
        private void drawArrow(Graphics2D g2d, int x1, int y1, int x2, int y2) {
            // Calculate the angle of the line
            double angle = Math.atan2(y2 - y1, x2 - x1);
            
            // Calculate the point where the arrow should be drawn (closer to the destination)
            int endX = (int) (x2 - NODE_RADIUS * Math.cos(angle));
            int endY = (int) (y2 - NODE_RADIUS * Math.sin(angle));
            
            // Draw the arrow lines
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.drawLine(endX, endY, 
                (int) (endX - ARROW_SIZE * Math.cos(angle - Math.PI/6)), 
                (int) (endY - ARROW_SIZE * Math.sin(angle - Math.PI/6)));
            
            g2d.drawLine(endX, endY, 
                (int) (endX - ARROW_SIZE * Math.cos(angle + Math.PI/6)), 
                (int) (endY - ARROW_SIZE * Math.sin(angle + Math.PI/6)));
            
            g2d.setColor(Color.LIGHT_GRAY);
        }
    }
}*/