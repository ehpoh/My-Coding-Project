/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment;

/**
 *
 * @author poher
 */
public class Edge {
    String destination;
    int time;
    double distance;

    public Edge(String destination, int time, double distance) {
        this.destination = destination;
        this.time = time;
        this.distance = distance;
    }
}
